package com.example.notifyrec;

import android.Manifest;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.view.MotionEvent;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends android.app.Activity {
    public static final String EXTRA_FORCE_SETTINGS = "force_settings";
    private static final int REQ_PERMS = 500;
    private static final int REQ_FOLDER = 501;

    private SharedPreferences prefs;
    private NToggleSwitch startupToggle;
    private NToggleSwitch saveSettingsToggle;
    private Button startServiceButton;
    private Button recordButton;
    private Button hideModeButton;
    private TextView bitrateLabel;
    private LinearLayout bitrateSegments;
    private Button hide30, hide60, hideInf;
    private Button formatM4a, formatWav;
    private Button rate441, rate480;
    private Button bitrate64, bitrate128, bitrate256;
    private Button audioMono, audioStereo;
    private Button sourceMic, sourceVoice;
    private ImageView completeExitFloating;
    private String pendingAction;

    private boolean exitDragging = false;
    private boolean exitLongPress = false;
    private float exitDownRawX, exitDownRawY, exitStartX, exitStartY;
    private Runnable exitLongPressRunnable;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) { updateRuntimeButtons(); }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(RecorderForegroundService.PREFS, MODE_PRIVATE);
        boolean forceSettings = getIntent() != null && getIntent().getBooleanExtra(EXTRA_FORCE_SETTINGS, false);

        if (!forceSettings && prefs.getBoolean(RecorderForegroundService.KEY_START_LAUNCHER_ON_APP_OPEN, false)
                && hasMicPermission()) {
            startRecorderService(RecorderForegroundService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 21) finishAndRemoveTask(); else finish();
            return;
        }

        setContentView(R.layout.activity_main);
        bindViews();
        bindSettings();
        bindCompleteExitFloating();
        renderAll();
        requestNeededPermissions();

        if (prefs.getBoolean(RecorderForegroundService.KEY_HIDE_ACTIVE, false)) {
            startRecorderService(RecorderForegroundService.ACTION_EXIT_HIDE_SETTINGS);
        }
        CrashLogger.log(this, "ACTIVITY onCreate forceSettings=" + forceSettings);
    }

    @Override protected void onStart() {
        super.onStart();
        IntentFilter f = new IntentFilter(RecorderForegroundService.ACTION_STATE_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(stateReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(stateReceiver, f);
    }

    @Override protected void onStop() {
        try { unregisterReceiver(stateReceiver); } catch (Exception ignored) {}
        super.onStop();
    }

    @Override protected void onResume() {
        super.onResume();
        if (startServiceButton != null) updateRuntimeButtons();
    }

    private void bindViews() {
        startupToggle = findViewById(R.id.start_launcher_on_app_open);
        saveSettingsToggle = findViewById(R.id.save_settings);
        startServiceButton = findViewById(R.id.start_service);
        recordButton = findViewById(R.id.record_button);
        hideModeButton = findViewById(R.id.hide_mode_button);
        bitrateLabel = findViewById(R.id.bitrate_label);
        bitrateSegments = findViewById(R.id.bitrate_segments);
        hide30 = findViewById(R.id.hide_30);
        hide60 = findViewById(R.id.hide_60);
        hideInf = findViewById(R.id.hide_inf);
        formatM4a = findViewById(R.id.format_m4a);
        formatWav = findViewById(R.id.format_wav);
        rate441 = findViewById(R.id.rate_441);
        rate480 = findViewById(R.id.rate_480);
        bitrate64 = findViewById(R.id.bitrate_64);
        bitrate128 = findViewById(R.id.bitrate_128);
        bitrate256 = findViewById(R.id.bitrate_256);
        audioMono = findViewById(R.id.audio_mono);
        audioStereo = findViewById(R.id.audio_stereo);
        sourceMic = findViewById(R.id.source_mic);
        sourceVoice = findViewById(R.id.source_voice);
        completeExitFloating = findViewById(R.id.complete_exit_floating);
    }

    private void bindSettings() {
        startupToggle.setChecked(prefs.getBoolean(RecorderForegroundService.KEY_START_LAUNCHER_ON_APP_OPEN, false));
        startupToggle.setOnCheckedChangeListener((v, checked) ->
                prefs.edit().putBoolean(RecorderForegroundService.KEY_START_LAUNCHER_ON_APP_OPEN, checked).apply());

        saveSettingsToggle.setChecked(prefs.getBoolean(RecorderForegroundService.KEY_SAVE_SETTINGS, true));
        saveSettingsToggle.setOnCheckedChangeListener((v, checked) ->
                prefs.edit().putBoolean(RecorderForegroundService.KEY_SAVE_SETTINGS, checked).apply());

        hide30.setOnClickListener(v -> { prefs.edit().putInt(RecorderForegroundService.KEY_HIDE_MINUTES, 30).apply(); renderHide(); });
        hide60.setOnClickListener(v -> { prefs.edit().putInt(RecorderForegroundService.KEY_HIDE_MINUTES, 60).apply(); renderHide(); });
        hideInf.setOnClickListener(v -> { prefs.edit().putInt(RecorderForegroundService.KEY_HIDE_MINUTES, 0).apply(); renderHide(); });

        formatM4a.setOnClickListener(v -> { SessionState.format = "m4a"; renderFormat(); });
        formatWav.setOnClickListener(v -> { SessionState.format = "wav"; renderFormat(); });

        rate441.setOnClickListener(v -> setInt(RecorderForegroundService.KEY_SAMPLE_RATE, 44100));
        rate480.setOnClickListener(v -> setInt(RecorderForegroundService.KEY_SAMPLE_RATE, 48000));
        bitrate64.setOnClickListener(v -> setInt(RecorderForegroundService.KEY_BITRATE, 64));
        bitrate128.setOnClickListener(v -> setInt(RecorderForegroundService.KEY_BITRATE, 128));
        bitrate256.setOnClickListener(v -> setInt(RecorderForegroundService.KEY_BITRATE, 256));
        audioMono.setOnClickListener(v -> setBool(RecorderForegroundService.KEY_STEREO, false));
        audioStereo.setOnClickListener(v -> setBool(RecorderForegroundService.KEY_STEREO, true));
        sourceMic.setOnClickListener(v -> setString(RecorderForegroundService.KEY_SOURCE, "mic"));
        sourceVoice.setOnClickListener(v -> setString(RecorderForegroundService.KEY_SOURCE, "voice"));

        findViewById(R.id.preset_minutes).setOnClickListener(v -> applyPreset(false));
        findViewById(R.id.preset_material).setOnClickListener(v -> applyPreset(true));

        startServiceButton.setOnClickListener(v -> {
            boolean active = prefs.getBoolean(RecorderForegroundService.KEY_SERVICE_ACTIVE, false);
            if (active) {
                startRecorderService(RecorderForegroundService.ACTION_COMPLETE_STOP);
            } else if (ensurePermissionFor(RecorderForegroundService.ACTION_START)) {
                startRecorderService(RecorderForegroundService.ACTION_START);
            }
        });

        recordButton.setOnClickListener(v -> {
            if (!ensurePermissionFor(RecorderForegroundService.ACTION_TOGGLE_RECORD)) return;
            startRecorderService(RecorderForegroundService.ACTION_TOGGLE_RECORD);
        });

        hideModeButton.setOnClickListener(v -> {
            if (!ensurePermissionFor(RecorderForegroundService.ACTION_HIDE_MODE)) return;
            startRecorderService(RecorderForegroundService.ACTION_HIDE_MODE);
            hideModeButton.postDelayed(() -> {
                if (Build.VERSION.SDK_INT >= 21) finishAndRemoveTask(); else finish();
            }, 160L);
        });

        findViewById(R.id.change_save_folder).setOnClickListener(v -> chooseSaveFolder());
        findViewById(R.id.show_diagnostic).setOnClickListener(v -> showDiagnostic());
    }

    private void setInt(String key, int value) {
        prefs.edit().putInt(key, value).apply();
        renderAll();
        settingsChanged();
    }
    private void setBool(String key, boolean value) {
        prefs.edit().putBoolean(key, value).apply();
        renderAll();
        settingsChanged();
    }
    private void setString(String key, String value) {
        prefs.edit().putString(key, value).apply();
        renderAll();
        settingsChanged();
    }

    private void applyPreset(boolean material) {
        SessionState.format = "m4a";
        prefs.edit()
                .putInt(RecorderForegroundService.KEY_SAMPLE_RATE, 48000)
                .putInt(RecorderForegroundService.KEY_BITRATE, material ? 256 : 128)
                .putBoolean(RecorderForegroundService.KEY_STEREO, material)
                .putString(RecorderForegroundService.KEY_SOURCE, "mic")
                .apply();
        renderAll();
        settingsChanged();
    }

    private void settingsChanged() {
        if (prefs.getBoolean(RecorderForegroundService.KEY_SERVICE_ACTIVE, false))
            startRecorderService(RecorderForegroundService.ACTION_SETTINGS_CHANGED);
    }

    private void renderAll() {
        renderHide();
        renderFormat();
        int rate = prefs.getInt(RecorderForegroundService.KEY_SAMPLE_RATE, 48000);
        selected(rate441, rate == 44100); selected(rate480, rate != 44100);
        int bitrate = prefs.getInt(RecorderForegroundService.KEY_BITRATE, 128);
        selected(bitrate64, bitrate == 64); selected(bitrate128, bitrate == 128); selected(bitrate256, bitrate == 256);
        boolean stereo = prefs.getBoolean(RecorderForegroundService.KEY_STEREO, false);
        selected(audioMono, !stereo); selected(audioStereo, stereo);
        String source = prefs.getString(RecorderForegroundService.KEY_SOURCE, "mic");
        selected(sourceMic, !"voice".equals(source)); selected(sourceVoice, "voice".equals(source));
        updateRuntimeButtons();
    }

    private void renderHide() {
        int m = prefs.getInt(RecorderForegroundService.KEY_HIDE_MINUTES, 30);
        selected(hide30, m == 30); selected(hide60, m == 60); selected(hideInf, m == 0);
    }

    private void renderFormat() {
        boolean wav = "wav".equals(SessionState.format);
        selected(formatM4a, !wav); selected(formatWav, wav);
        bitrateLabel.setAlpha(wav ? 0.38f : 1f);
        bitrateSegments.setAlpha(wav ? 0.45f : 1f);
        bitrate64.setEnabled(!wav); bitrate128.setEnabled(!wav); bitrate256.setEnabled(!wav);
        if (wav) {
            bitrate64.setBackgroundResource(R.drawable.button_dark_gray);
            bitrate128.setBackgroundResource(R.drawable.button_dark_gray);
            bitrate256.setBackgroundResource(R.drawable.button_dark_gray);
            int disabledText = android.graphics.Color.rgb(110, 110, 110);
            bitrate64.setTextColor(disabledText); bitrate128.setTextColor(disabledText); bitrate256.setTextColor(disabledText);
        } else {
            int bitrate = prefs.getInt(RecorderForegroundService.KEY_BITRATE, 128);
            selected(bitrate64, bitrate == 64); selected(bitrate128, bitrate == 128); selected(bitrate256, bitrate == 256);
        }
    }

    private void selected(Button b, boolean yes) {
        b.setBackgroundResource(yes ? R.drawable.button_light_blue : R.drawable.button_dark_gray);
        b.setTextColor(yes ? android.graphics.Color.WHITE : android.graphics.Color.rgb(235, 235, 235));
    }

    private void updateRuntimeButtons() {
        boolean active = prefs.getBoolean(RecorderForegroundService.KEY_SERVICE_ACTIVE, false);
        boolean recording = prefs.getBoolean(RecorderForegroundService.KEY_RECORDING, false);
        startServiceButton.setText(active ? "通知ランチャー停止" : "通知ランチャー起動");
        startServiceButton.setBackgroundResource(active ? R.drawable.button_dark_gray : R.drawable.button_orange);
        if (recordButton != null) {
            recordButton.setText(recording ? "録音停止" : "録音開始");
            recordButton.setBackgroundResource(recording ? R.drawable.button_dark_gray : R.drawable.button_dark_red);
            recordButton.setTextColor(recording
                    ? android.graphics.Color.rgb(136, 34, 17)
                    : android.graphics.Color.WHITE);
        }
    }

    private void bindCompleteExitFloating() {
        if (completeExitFloating == null) return;
        completeExitFloating.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    exitDragging = false;
                    exitLongPress = false;
                    exitDownRawX = event.getRawX();
                    exitDownRawY = event.getRawY();
                    exitStartX = v.getX();
                    exitStartY = v.getY();
                    exitLongPressRunnable = () -> {
                        exitLongPress = true;
                        exitDragging = true;
                        vibrateExitLongPress();
                        v.animate().cancel();
                        v.animate().scaleX(1.18f).scaleY(1.18f).setDuration(45L)
                                .setInterpolator(new AccelerateInterpolator())
                                .withEndAction(() -> v.animate().scaleX(1f).scaleY(1f)
                                        .setDuration(155L).setInterpolator(new DecelerateInterpolator()).start())
                                .start();
                    };
                    v.postDelayed(exitLongPressRunnable, 300L);
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - exitDownRawX;
                    float dy = event.getRawY() - exitDownRawY;
                    if (!exitLongPress && (Math.abs(dx) > 24f || Math.abs(dy) > 24f)) {
                        if (exitLongPressRunnable != null) v.removeCallbacks(exitLongPressRunnable);
                    }
                    if (exitDragging) {
                        View parent = (View) v.getParent();
                        float nx = Math.max(0f, Math.min(exitStartX + dx, parent.getWidth() - v.getWidth()));
                        float ny = Math.max(0f, Math.min(exitStartY + dy, parent.getHeight() - v.getHeight()));
                        v.setX(nx);
                        v.setY(ny);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (exitLongPressRunnable != null) v.removeCallbacks(exitLongPressRunnable);
                    if (event.getActionMasked() == MotionEvent.ACTION_UP && !exitLongPress && !exitDragging) {
                        animateCompleteExit();
                    }
                    exitDragging = false;
                    exitLongPress = false;
                    return true;
            }
            return false;
        });
    }

    private void vibrateExitLongPress() {
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        if (vibrator == null || !vibrator.hasVibrator()) return;
        if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(40L, 200));
        else vibrator.vibrate(40L);
    }

    private void animateCompleteExit() {
        if (completeExitFloating == null) {
            requestCompleteExit();
            return;
        }
        completeExitFloating.animate().cancel();
        completeExitFloating.animate()
                .scaleX(3f).scaleY(3f).alpha(0f)
                .setDuration(200L)
                .setInterpolator(new AccelerateInterpolator(2.0f))
                .withEndAction(this::requestCompleteExit)
                .start();
    }

    private void requestCompleteExit() {
        Intent i = new Intent(this, RecorderForegroundService.class);
        i.setAction(RecorderForegroundService.ACTION_COMPLETE_STOP);
        try { startService(i); } catch (Exception e) {
            CrashLogger.log(this, "COMPLETE STOP UI start warning " + e);
        }
        getWindow().getDecorView().postDelayed(this::finishCompletely, 80L);
    }

    private void finishCompletely() {
        if (Build.VERSION.SDK_INT >= 21) finishAndRemoveTask();
        else finish();
    }

    private boolean hasMicPermission() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean ensurePermissionFor(String action) {
        if (hasMicPermission()) return true;
        pendingAction = action;
        requestNeededPermissions();
        return false;
    }

    private void requestNeededPermissions() {
        java.util.ArrayList<String> missing = new java.util.ArrayList<>();
        if (!hasMicPermission()) missing.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            missing.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!missing.isEmpty()) requestPermissions(missing.toArray(new String[0]), REQ_PERMS);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode != REQ_PERMS) return;
        if (hasMicPermission() && pendingAction != null) {
            String a = pendingAction;
            pendingAction = null;
            startRecorderService(a);
        }
    }

    private void startRecorderService(String action) {
        Intent i = new Intent(this, RecorderForegroundService.class).setAction(action);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    private void chooseSaveFolder() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
        startActivityForResult(i, REQ_FOLDER);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_FOLDER || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        int take = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        try { getContentResolver().takePersistableUriPermission(uri, take); } catch (Exception e) {
            CrashLogger.log(this, "FOLDER persist permission warning " + e);
        }
        prefs.edit().putString(RecorderForegroundService.KEY_SAVE_TREE, uri.toString()).apply();
        Toast.makeText(this, "保存フォルダを変更しました", Toast.LENGTH_SHORT).show();
        CrashLogger.log(this, "FOLDER " + uri);
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private android.graphics.drawable.GradientDrawable makeRoundedDialogPanel(int color) {
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(10));
        return bg;
    }

    private void prepareRoundedDialog(AlertDialog dialog) {
        if (dialog == null || dialog.getWindow() == null) return;
        dialog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
        android.view.View decor = dialog.getWindow().getDecorView();
        decor.setBackground(makeRoundedDialogPanel(android.graphics.Color.TRANSPARENT));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) decor.setClipToOutline(true);
    }

    private TextView makeDialogAction(String label) {
        TextView action = new TextView(this);
        action.setText(label);
        action.setTextSize(15f);
        action.setTextColor(android.graphics.Color.rgb(170, 205, 205));
        action.setGravity(android.view.Gravity.CENTER);
        action.setPadding(dp(8), 0, dp(8), 0);
        action.setBackground(new android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT));
        return action;
    }

    private String buildDiagnosticReport() {
        String version = "?";
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            version = pi.versionName + " (" + pi.getLongVersionCode() + ")";
        } catch (Exception ignored) {}
        return "通知Rec. diagnostic report\n"
                + "Generated: " + new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.US).format(new java.util.Date()) + "\n"
                + "Device: " + Build.MANUFACTURER + " " + Build.MODEL + "\n"
                + "Android: " + Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")\n"
                + "App: " + version + "\n\n"
                + "--- STATE ---\n"
                + "service=" + prefs.getBoolean(RecorderForegroundService.KEY_SERVICE_ACTIVE, false) + "\n"
                + "recording=" + prefs.getBoolean(RecorderForegroundService.KEY_RECORDING, false) + "\n"
                + "hide=" + prefs.getBoolean(RecorderForegroundService.KEY_HIDE_ACTIVE, false) + "\n"
                + "hideMinutes=" + prefs.getInt(RecorderForegroundService.KEY_HIDE_MINUTES, 30) + "\n"
                + "saveSettings=" + prefs.getBoolean(RecorderForegroundService.KEY_SAVE_SETTINGS, true) + "\n"
                + "format=" + SessionState.format + " (WAV is session-only)\n"
                + "sampleRate=" + prefs.getInt(RecorderForegroundService.KEY_SAMPLE_RATE, 48000) + "\n"
                + "bitrate=" + prefs.getInt(RecorderForegroundService.KEY_BITRATE, 128) + "kbps\n"
                + "stereo=" + prefs.getBoolean(RecorderForegroundService.KEY_STEREO, false) + "\n"
                + "source=" + prefs.getString(RecorderForegroundService.KEY_SOURCE, "mic") + "\n"
                + "saveTree=" + prefs.getString(RecorderForegroundService.KEY_SAVE_TREE, "(Music/通知Rec. default)") + "\n\n"
                + "--- LOG ---\n" + CrashLogger.read(this);
    }

    private void showDiagnostic() {
        CrashLogger.log(this, "LOG dialog open");

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(16), dp(14), dp(16), dp(10));
        panel.setBackground(makeRoundedDialogPanel(android.graphics.Color.rgb(70, 70, 70)));

        TextView reportView = new TextView(this);
        reportView.setText(buildDiagnosticReport());
        reportView.setTextSize(12.5f);
        reportView.setTextColor(android.graphics.Color.rgb(235, 235, 235));
        reportView.setTypeface(android.graphics.Typeface.MONOSPACE);
        reportView.setTextIsSelectable(true);
        reportView.setPadding(dp(2), dp(2), dp(2), dp(8));

        android.widget.ScrollView logScroll = new android.widget.ScrollView(this);
        logScroll.setFillViewport(true);
        logScroll.setVerticalScrollBarEnabled(true);
        logScroll.setScrollBarStyle(android.view.View.SCROLLBARS_INSIDE_OVERLAY);
        logScroll.setScrollbarFadingEnabled(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            android.graphics.drawable.GradientDrawable thumb = new android.graphics.drawable.GradientDrawable();
            thumb.setColor(android.graphics.Color.rgb(90, 85, 85)); // N light gray #5A5555
            thumb.setCornerRadius(dp(2));
            thumb.setSize(dp(3), dp(36));
            logScroll.setVerticalScrollbarThumbDrawable(thumb);
            android.graphics.drawable.GradientDrawable track = new android.graphics.drawable.GradientDrawable();
            track.setColor(android.graphics.Color.TRANSPARENT);
            logScroll.setVerticalScrollbarTrackDrawable(track);
        }
        logScroll.addView(reportView, new android.widget.ScrollView.LayoutParams(-1, -2));
        int desiredLogHeight = Math.max(dp(320), Math.round(getResources().getDisplayMetrics().heightPixels * 0.62f));
        panel.addView(logScroll, new LinearLayout.LayoutParams(-1, desiredLogHeight));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView clearAction = makeDialogAction("ログ消去");
        TextView copyAction = makeDialogAction("コピー");
        TextView closeAction = makeDialogAction("閉じる");
        clearAction.setGravity(android.view.Gravity.CENTER_VERTICAL | android.view.Gravity.START);

        LinearLayout rightActions = new LinearLayout(this);
        rightActions.setOrientation(LinearLayout.HORIZONTAL);
        rightActions.setGravity(android.view.Gravity.CENTER_VERTICAL | android.view.Gravity.END);
        rightActions.addView(copyAction, new LinearLayout.LayoutParams(dp(92), dp(48)));
        rightActions.addView(closeAction, new LinearLayout.LayoutParams(dp(92), dp(48)));
        actions.addView(clearAction, new LinearLayout.LayoutParams(0, dp(48), 1f));
        actions.addView(rightActions, new LinearLayout.LayoutParams(-2, dp(48)));
        panel.addView(actions, new LinearLayout.LayoutParams(-1, dp(48)));

        AlertDialog dialog = new AlertDialog.Builder(this).setView(panel).create();
        prepareRoundedDialog(dialog);

        clearAction.setOnClickListener(v -> {
            CrashLogger.clear(this);
            reportView.setText(buildDiagnosticReport());
            Toast.makeText(this, "診断ログを消去しました", Toast.LENGTH_SHORT).show();
        });
        copyAction.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("通知Rec. diagnostic", buildDiagnosticReport()));
            Toast.makeText(this, "診断ログをコピーしました", Toast.LENGTH_SHORT).show();
        });
        closeAction.setOnClickListener(v -> dialog.dismiss());
        dialog.show();
    }

}