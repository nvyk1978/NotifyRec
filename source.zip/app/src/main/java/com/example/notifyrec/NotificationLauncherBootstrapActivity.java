package com.example.notifyrec;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;

/** Foreground bridge for QS -> microphone foreground service on Android 14+. */
public class NotificationLauncherBootstrapActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            startActivity(new Intent(this, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra(MainActivity.EXTRA_FORCE_SETTINGS, true));
            finish();
            overridePendingTransition(0, 0);
            return;
        }
        Intent service = new Intent(this, RecorderForegroundService.class)
                .setAction(RecorderForegroundService.ACTION_START);
        startForegroundService(service);
        finish();
        overridePendingTransition(0, 0);
    }
}
