package com.example.notifyrec;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;

/**
 * Invisible/transparent bridge used only by the Quick Settings tile.
 *
 * Android 14+ requires a foreground/eligible UI state before starting a
 * microphone foreground service. This Activity lives in its own temporary
 * task so invoking the QS tile never brings an existing MainActivity task
 * (the settings screen) to the foreground.
 */
public class NotificationLauncherBootstrapActivity extends Activity {
    private static final int REQ_MIC = 610;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        CrashLogger.log(this, "QS bootstrap onCreate");

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            // Ask only for the required system permission here. Do not open MainActivity.
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }

        startLauncherServiceAndFinish();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MIC && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            CrashLogger.log(this, "QS microphone permission granted");
            startLauncherServiceAndFinish();
        } else {
            CrashLogger.log(this, "QS microphone permission denied");
            finishBridgeTask();
        }
    }

    private void startLauncherServiceAndFinish() {
        try {
            Intent service = new Intent(this, RecorderForegroundService.class)
                    .setAction(RecorderForegroundService.ACTION_START);
            startForegroundService(service);
            CrashLogger.log(this, "QS launcher service requested");
        } catch (Exception e) {
            CrashLogger.log(this, "QS launcher start failed=" + e.getClass().getSimpleName());
        }
        finishBridgeTask();
    }

    private void finishBridgeTask() {
        // This Activity has a dedicated taskAffinity; removing this temporary task
        // returns the user to whatever app was visible before opening Quick Settings.
        finishAndRemoveTask();
        overridePendingTransition(0, 0);
    }
}
