package com.example.notifyrec;

import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class CrashLogger {
    private static final String FILE = "notifyrec.log";
    private static final long MAX = 180_000L;
    private CrashLogger() {}

    public static synchronized void log(Context c, String message) {
        String line = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
                .format(new Date()) + " [" + Thread.currentThread().getName() + "] " + message + "\n";
        try {
            File f = new File(c.getFilesDir(), FILE);
            if (f.exists() && f.length() > MAX) {
                byte[] all = java.nio.file.Files.readAllBytes(f.toPath());
                int keep = Math.min(all.length, 90_000);
                try (FileOutputStream out = new FileOutputStream(f, false)) {
                    out.write(all, all.length - keep, keep);
                }
            }
            try (FileOutputStream out = new FileOutputStream(f, true)) {
                out.write(line.getBytes(StandardCharsets.UTF_8));
            }
        } catch (Exception ignored) {}
    }

    public static synchronized String read(Context c) {
        try {
            File f = new File(c.getFilesDir(), FILE);
            if (!f.exists()) return "(log empty)";
            return new String(java.nio.file.Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "(log read failed: " + e + ")";
        }
    }
}
