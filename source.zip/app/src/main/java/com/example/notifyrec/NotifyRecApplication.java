package com.example.notifyrec;

import android.app.Application;
import android.content.Context;

public class NotifyRecApplication extends Application {
    @Override public void onCreate() {
        super.onCreate();
        SessionState.format = "m4a";
        android.content.SharedPreferences prefs = getSharedPreferences(RecorderForegroundService.PREFS, Context.MODE_PRIVATE);
        android.content.SharedPreferences.Editor editor = prefs.edit();
        // 「設定を保存する」がOFFなら、録音設定だけをプロセス起動時に既定値へ戻す。
        // 起動方法・保存フォルダ・このトグル自体は保持する。WAVは従来どおり常にセッション限定。
        if (!prefs.getBoolean(RecorderForegroundService.KEY_SAVE_SETTINGS, true)) {
            editor.putInt(RecorderForegroundService.KEY_HIDE_MINUTES, 30)
                    .putInt(RecorderForegroundService.KEY_SAMPLE_RATE, 48000)
                    .putInt(RecorderForegroundService.KEY_BITRATE, 128)
                    .putBoolean(RecorderForegroundService.KEY_STEREO, false)
                    .putString(RecorderForegroundService.KEY_SOURCE, "mic");
        }
        editor.putBoolean(RecorderForegroundService.KEY_SERVICE_ACTIVE, false)
                .putBoolean(RecorderForegroundService.KEY_RECORDING, false)
                .putBoolean(RecorderForegroundService.KEY_HIDE_ACTIVE, false)
                .remove(RecorderForegroundService.KEY_HIDE_DEADLINE)
                .apply();
        CrashLogger.log(this, "APP_PROCESS_START");
    }
}
