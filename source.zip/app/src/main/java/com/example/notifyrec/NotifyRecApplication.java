package com.example.notifyrec;

import android.app.Application;
import android.content.Context;

public class NotifyRecApplication extends Application {
    @Override public void onCreate() {
        super.onCreate();
        SessionState.format = "m4a";
        getSharedPreferences(RecorderForegroundService.PREFS, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(RecorderForegroundService.KEY_SERVICE_ACTIVE, false)
                .putBoolean(RecorderForegroundService.KEY_RECORDING, false)
                .putBoolean(RecorderForegroundService.KEY_HIDE_ACTIVE, false)
                .remove(RecorderForegroundService.KEY_HIDE_DEADLINE)
                .apply();
        CrashLogger.log(this, "APP_PROCESS_START");
    }
}
