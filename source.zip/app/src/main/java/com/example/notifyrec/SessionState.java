package com.example.notifyrec;

/** Process-local choices. WAV is intentionally not persisted across process/app restarts. */
public final class SessionState {
    private SessionState() {}
    public static volatile String format = "m4a";
}
