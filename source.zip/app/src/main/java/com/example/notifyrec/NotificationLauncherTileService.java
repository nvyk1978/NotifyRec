package com.example.notifyrec;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

public class NotificationLauncherTileService extends TileService {
    @Override public void onStartListening() {
        super.onStartListening();
        Tile tile = getQsTile();
        if (tile == null) return;
        boolean active = getSharedPreferences(RecorderForegroundService.PREFS, Context.MODE_PRIVATE)
                .getBoolean(RecorderForegroundService.KEY_SERVICE_ACTIVE, false);
        tile.setState(active ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        tile.setLabel("通知Rec.");
        tile.updateTile();
    }

    @Override public void onClick() {
        super.onClick();
        Intent i = new Intent(this, NotificationLauncherBootstrapActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        PendingIntent pi = PendingIntent.getActivity(this, 210, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (Build.VERSION.SDK_INT >= 34) startActivityAndCollapse(pi);
        else startActivityAndCollapse(i);
    }
}
