package com.example.notifyrec;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.widget.RemoteViews;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class RecorderForegroundService extends Service {
    public static final String PREFS = "notifyrec_prefs";
    public static final String KEY_SERVICE_ACTIVE = "service_active";
    public static final String KEY_RECORDING = "recording";
    public static final String KEY_HIDE_ACTIVE = "hide_active";
    public static final String KEY_HIDE_DEADLINE = "hide_deadline";
    public static final String KEY_START_LAUNCHER_ON_APP_OPEN = "start_launcher_on_app_open";
    public static final String KEY_HIDE_MINUTES = "hide_minutes";
    public static final String KEY_SAMPLE_RATE = "sample_rate";
    public static final String KEY_BITRATE = "bitrate_kbps";
    public static final String KEY_STEREO = "stereo";
    public static final String KEY_SOURCE = "input_source";
    public static final String KEY_SAVE_TREE = "save_tree_uri";

    public static final String ACTION_START = "com.example.notifyrec.START";
    public static final String ACTION_TOGGLE_RECORD = "com.example.notifyrec.TOGGLE_RECORD";
    public static final String ACTION_HIDE_MODE = "com.example.notifyrec.HIDE_MODE";
    public static final String ACTION_COMPLETE_STOP = "com.example.notifyrec.COMPLETE_STOP";
    public static final String ACTION_EXIT_HIDE_SETTINGS = "com.example.notifyrec.EXIT_HIDE_SETTINGS";
    public static final String ACTION_SETTINGS_CHANGED = "com.example.notifyrec.SETTINGS_CHANGED";
    public static final String ACTION_STATE_CHANGED = "com.example.notifyrec.STATE_CHANGED";

    private static final String CHANNEL_LAUNCHER = "notifyrec_launcher_v1";
    private static final String CHANNEL_HIDE = "notifyrec_hide_v1";
    private static final int NOTIFICATION_ID = 31;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Object audioLock = new Object();
    private volatile boolean captureRunning = false;
    private Thread captureThread;
    private AudioRecord audioRecord;
    private int activeSampleRate = 48000;
    private int activeChannels = 1;
    private volatile RecordWriter currentWriter;
    private Runnable hideTimeout;
    private volatile boolean completeStopInProgress = false;
    private volatile boolean serviceDestroying = false;

    @Override public void onCreate() {
        super.onCreate();
        createChannels();
        CrashLogger.log(this, "SERVICE onCreate");
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null && intent.getAction() != null ? intent.getAction() : ACTION_START;
        CrashLogger.log(this, "SERVICE action=" + action + " flags=" + flags + " startId=" + startId);

        if (ACTION_COMPLETE_STOP.equals(action)) {
            completeStop("explicit");
            return START_NOT_STICKY;
        }

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            CrashLogger.log(this, "SERVICE microphone permission missing");
            stopSelf();
            return START_NOT_STICKY;
        }

        SharedPreferences p = prefs();
        boolean hiding = p.getBoolean(KEY_HIDE_ACTIVE, false);
        startForeground(NOTIFICATION_ID, hiding ? buildHideNotification() : buildLauncherNotification());
        p.edit().putBoolean(KEY_SERVICE_ACTIVE, true).apply();
        ensureAudioInput();

        if (ACTION_TOGGLE_RECORD.equals(action)) {
            if (p.getBoolean(KEY_RECORDING, false)) stopRecording(true);
            else startRecording(false);
        } else if (ACTION_HIDE_MODE.equals(action)) {
            enterHideMode();
        } else if (ACTION_EXIT_HIDE_SETTINGS.equals(action)) {
            exitHideForSettings();
        } else if (ACTION_SETTINGS_CHANGED.equals(action)) {
            if (!p.getBoolean(KEY_RECORDING, false)) restartAudioInput();
            refreshNotification();
        } else if (ACTION_START.equals(action)) {
            if (p.getBoolean(KEY_HIDE_ACTIVE, false)) {
                // Explicit QS/app start exposes the launcher again but keeps an active recording.
                leaveHideKeepingRecording();
            } else {
                refreshNotification();
            }
        }

        broadcastState();
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        serviceDestroying = true;
        cancelHideTimeout();
        if (!completeStopInProgress) {
            stopRecording(false);
            stopAudioInput();
            prefs().edit()
                    .putBoolean(KEY_SERVICE_ACTIVE, false)
                    .putBoolean(KEY_RECORDING, false)
                    .putBoolean(KEY_HIDE_ACTIVE, false)
                    .remove(KEY_HIDE_DEADLINE)
                    .apply();
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.cancel(NOTIFICATION_ID);
            broadcastState();
        }
        CrashLogger.log(this, "SERVICE onDestroy completeStop=" + completeStopInProgress);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private SharedPreferences prefs() {
        return getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private void createChannels() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm == null || Build.VERSION.SDK_INT < 26) return;
        NotificationChannel launcher = new NotificationChannel(
                CHANNEL_LAUNCHER, "通知ランチャー", NotificationManager.IMPORTANCE_LOW);
        launcher.setSound(null, null);
        launcher.enableVibration(false);
        launcher.setShowBadge(false);
        nm.createNotificationChannel(launcher);

        NotificationChannel hide = new NotificationChannel(
                CHANNEL_HIDE, "1 new message", NotificationManager.IMPORTANCE_MIN);
        hide.setSound(null, null);
        hide.enableVibration(false);
        hide.setShowBadge(false);
        hide.setLockscreenVisibility(Notification.VISIBILITY_SECRET);
        nm.createNotificationChannel(hide);
    }

    private Notification buildLauncherNotification() {
        boolean recording = prefs().getBoolean(KEY_RECORDING, false);
        PendingIntent exitPi = servicePi(1, ACTION_COMPLETE_STOP);
        PendingIntent hidePi = servicePi(2, ACTION_HIDE_MODE);
        PendingIntent recordPi = servicePi(3, ACTION_TOGGLE_RECORD);

        Intent open = new Intent(this, MainActivity.class)
                .putExtra(MainActivity.EXTRA_FORCE_SETTINGS, true)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 4, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        RemoteViews rv = new RemoteViews(getPackageName(), R.layout.notification_recorder);
        rv.setImageViewResource(R.id.notification_exit_icon, R.drawable.ic_exit_red);
        rv.setOnClickPendingIntent(R.id.notification_exit, exitPi);
        rv.setOnClickPendingIntent(R.id.notification_hide, hidePi);
        rv.setOnClickPendingIntent(R.id.notification_record, recordPi);
        rv.setTextViewText(R.id.notification_record, recording ? "STOP" : "REC");
        rv.setInt(R.id.notification_record, "setBackgroundResource",
                recording ? R.drawable.button_record_stop : R.drawable.button_blue);
        rv.setTextColor(R.id.notification_record, Color.WHITE);

        Notification.Builder b = new Notification.Builder(this, CHANNEL_LAUNCHER)
                .setSmallIcon(R.drawable.ic_notification_dot)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openPi)
                .setCustomContentView(rv)
                .setStyle(new Notification.DecoratedCustomViewStyle())
                .setCategory(Notification.CATEGORY_SERVICE)
                .setVisibility(Notification.VISIBILITY_PRIVATE);
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        return b.build();
    }

    private Notification buildHideNotification() {
        Intent open = new Intent(this, MainActivity.class)
                .putExtra(MainActivity.EXTRA_FORCE_SETTINGS, true)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this, 5, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL_HIDE)
                .setSmallIcon(R.drawable.ic_notification_dot)
                .setContentTitle("1 new message")
                .setContentText("")
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openPi)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setVisibility(Notification.VISIBILITY_SECRET)
                .build();
    }

    private PendingIntent servicePi(int request, String action) {
        Intent i = new Intent(this, RecorderForegroundService.class).setAction(action);
        return PendingIntent.getService(this, request, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private void refreshNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm == null) return;
        boolean hidden = prefs().getBoolean(KEY_HIDE_ACTIVE, false);
        nm.notify(NOTIFICATION_ID, hidden ? buildHideNotification() : buildLauncherNotification());
    }

    private void ensureAudioInput() {
        synchronized (audioLock) {
            if (audioRecord != null && captureRunning) return;
            openAudioInputLocked();
        }
    }

    private void restartAudioInput() {
        synchronized (audioLock) {
            stopAudioInputLocked();
            openAudioInputLocked();
        }
    }

    private void openAudioInputLocked() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return;
        SharedPreferences p = prefs();
        int requestedRate = p.getInt(KEY_SAMPLE_RATE, 48000);
        boolean requestedStereo = p.getBoolean(KEY_STEREO, false);
        int source = "voice".equals(p.getString(KEY_SOURCE, "mic"))
                ? MediaRecorder.AudioSource.VOICE_COMMUNICATION
                : MediaRecorder.AudioSource.MIC;

        AudioRecord opened = tryBuildAudioRecord(source, requestedRate, requestedStereo);
        if (opened == null && requestedStereo) {
            CrashLogger.log(this, "AUDIO stereo unavailable -> mono fallback");
            opened = tryBuildAudioRecord(source, requestedRate, false);
        }
        if (opened == null && requestedRate != 48000) {
            opened = tryBuildAudioRecord(source, 48000, false);
        }
        if (opened == null) {
            CrashLogger.log(this, "AUDIO open failed");
            main.post(() -> Toast.makeText(this, "マイクを開始できませんでした", Toast.LENGTH_LONG).show());
            return;
        }

        audioRecord = opened;
        activeSampleRate = opened.getSampleRate();
        activeChannels = opened.getChannelCount();
        captureRunning = true;
        try {
            opened.startRecording();
        } catch (Exception e) {
            CrashLogger.log(this, "AUDIO start failed: " + e);
            opened.release();
            audioRecord = null;
            captureRunning = false;
            return;
        }

        int frameBytes = Math.max(2, activeChannels * 2);
        int chunk = Math.max(4096, activeSampleRate * frameBytes / 10);
        captureThread = new Thread(() -> captureLoop(chunk), "NotifyRecAudio");
        captureThread.start();
        CrashLogger.log(this, "AUDIO active rate=" + activeSampleRate + " channels=" + activeChannels
                + " source=" + source + " privacy_indicator=ON");
    }

    private AudioRecord tryBuildAudioRecord(int source, int rate, boolean stereo) {
        int channelMask = stereo ? AudioFormat.CHANNEL_IN_STEREO : AudioFormat.CHANNEL_IN_MONO;
        int min = AudioRecord.getMinBufferSize(rate, channelMask, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) return null;
        try {
            AudioRecord rec = new AudioRecord.Builder()
                    .setAudioSource(source)
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(rate)
                            .setChannelMask(channelMask)
                            .build())
                    .setBufferSizeInBytes(Math.max(min * 2, rate * (stereo ? 4 : 2) / 2))
                    .build();
            if (rec.getState() != AudioRecord.STATE_INITIALIZED) {
                rec.release();
                return null;
            }
            return rec;
        } catch (Exception e) {
            CrashLogger.log(this, "AUDIO build failed rate=" + rate + " stereo=" + stereo + " " + e);
            return null;
        }
    }

    private void captureLoop(int chunkSize) {
        byte[] buffer = new byte[chunkSize];
        while (captureRunning) {
            AudioRecord rec = audioRecord;
            if (rec == null) break;
            int n;
            try {
                n = rec.read(buffer, 0, buffer.length, AudioRecord.READ_BLOCKING);
            } catch (Exception e) {
                CrashLogger.log(this, "AUDIO read exception " + e);
                break;
            }
            if (n > 0) {
                RecordWriter writer = currentWriter;
                if (writer != null) {
                    try {
                        writer.write(buffer, n);
                    } catch (Exception e) {
                        CrashLogger.log(this, "RECORD writer error " + e);
                        main.post(() -> stopRecording(true));
                    }
                }
            }
        }
    }

    private void stopAudioInput() {
        synchronized (audioLock) { stopAudioInputLocked(); }
    }

    private void stopAudioInputLocked() {
        if (!captureRunning && audioRecord == null && captureThread == null) return;
        captureRunning = false;
        AudioRecord rec = audioRecord;
        audioRecord = null;
        if (rec != null) {
            try { rec.stop(); } catch (Exception ignored) {}
            try { rec.release(); } catch (Exception ignored) {}
        }
        Thread t = captureThread;
        captureThread = null;
        if (t != null && t != Thread.currentThread()) {
            try { t.join(400L); } catch (InterruptedException ignored) {}
        }
        CrashLogger.log(this, "AUDIO inactive privacy_indicator=OFF");
    }

    private void startRecording(boolean fromHide) {
        if (prefs().getBoolean(KEY_RECORDING, false)) return;
        ensureAudioInput();
        if (audioRecord == null) return;

        String format = SessionState.format;
        int bitrate = prefs().getInt(KEY_BITRATE, 128) * 1000;
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String ext = "wav".equals(format) ? ".wav" : ".m4a";
        String displayName = "NotifyRec_" + stamp + ext;
        File temp = new File(getCacheDir(), "recording_" + System.currentTimeMillis() + ext);
        try {
            RecordWriter writer = "wav".equals(format)
                    ? new WavWriter(temp, activeSampleRate, activeChannels)
                    : new M4aWriter(temp, activeSampleRate, activeChannels, bitrate);
            writer.displayName = displayName;
            currentWriter = writer;
            prefs().edit().putBoolean(KEY_RECORDING, true).apply();
            CrashLogger.log(this, "RECORD START format=" + format + " rate=" + activeSampleRate
                    + " channels=" + activeChannels + " bitrate=" + bitrate + " hide=" + fromHide);
            refreshNotification();
            broadcastState();
        } catch (Exception e) {
            CrashLogger.log(this, "RECORD start failed " + e);
            main.post(() -> Toast.makeText(this, "録音を開始できませんでした", Toast.LENGTH_LONG).show());
        }
    }

    private void stopRecording(boolean showToast) {
        RecordWriter writer = currentWriter;
        currentWriter = null;
        boolean wasRecording = prefs().getBoolean(KEY_RECORDING, false);
        prefs().edit().putBoolean(KEY_RECORDING, false).apply();
        if (writer != null) {
            try {
                writer.finish();
                Uri saved = publishRecording(writer.file, writer.displayName,
                        writer instanceof WavWriter ? "audio/wav" : "audio/mp4");
                CrashLogger.log(this, "RECORD STOP saved=" + saved + " name=" + writer.displayName);
                if (showToast) main.post(() -> Toast.makeText(this, "録音を保存しました", Toast.LENGTH_SHORT).show());
            } catch (Exception e) {
                CrashLogger.log(this, "RECORD finalize failed " + e);
                if (showToast) main.post(() -> Toast.makeText(this, "録音の保存に失敗しました", Toast.LENGTH_LONG).show());
            } finally {
                try { writer.file.delete(); } catch (Exception ignored) {}
            }
        } else if (wasRecording) {
            CrashLogger.log(this, "RECORD STOP state-only");
        }
        if (!completeStopInProgress && !serviceDestroying) {
            refreshNotification();
            broadcastState();
        }
    }

    private Uri publishRecording(File temp, String displayName, String mime) throws Exception {
        ContentResolver resolver = getContentResolver();
        String treeString = prefs().getString(KEY_SAVE_TREE, null);
        if (treeString != null && !treeString.isEmpty()) {
            try {
                Uri tree = Uri.parse(treeString);
                String docId = DocumentsContract.getTreeDocumentId(tree);
                Uri parent = DocumentsContract.buildDocumentUriUsingTree(tree, docId);
                Uri child = DocumentsContract.createDocument(resolver, parent, mime, displayName);
                if (child != null) {
                    try (FileInputStream in = new FileInputStream(temp);
                         OutputStream out = resolver.openOutputStream(child, "w")) {
                        if (out == null) throw new IllegalStateException("openOutputStream null");
                        copy(in, out);
                    }
                    return child;
                }
            } catch (Exception e) {
                CrashLogger.log(this, "SAVE custom folder failed -> MediaStore: " + e);
            }
        }

        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Audio.Media.DISPLAY_NAME, displayName);
        cv.put(MediaStore.Audio.Media.MIME_TYPE, mime);
        if (Build.VERSION.SDK_INT >= 29) {
            cv.put(MediaStore.Audio.Media.RELATIVE_PATH, "Recordings");
            cv.put(MediaStore.Audio.Media.IS_PENDING, 1);
        }
        Uri uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, cv);
        if (uri == null) throw new IllegalStateException("MediaStore insert failed");
        try (FileInputStream in = new FileInputStream(temp);
             OutputStream out = resolver.openOutputStream(uri, "w")) {
            if (out == null) throw new IllegalStateException("MediaStore output null");
            copy(in, out);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues done = new ContentValues();
            done.put(MediaStore.Audio.Media.IS_PENDING, 0);
            resolver.update(uri, done, null, null);
        }
        return uri;
    }

    private static void copy(FileInputStream in, OutputStream out) throws Exception {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) >= 0) if (n > 0) out.write(buf, 0, n);
        out.flush();
    }

    private void enterHideMode() {
        if (!prefs().getBoolean(KEY_RECORDING, false)) startRecording(true);
        long minutes = prefs().getInt(KEY_HIDE_MINUTES, 30);
        long deadline = minutes <= 0 ? Long.MAX_VALUE : System.currentTimeMillis() + minutes * 60_000L;
        prefs().edit()
                .putBoolean(KEY_HIDE_ACTIVE, true)
                .putLong(KEY_HIDE_DEADLINE, deadline)
                .apply();
        refreshNotification();
        scheduleHideTimeout(deadline);
        CrashLogger.log(this, "HIDE ON minutes=" + minutes + " deadline=" + deadline);
        broadcastState();
    }

    private void scheduleHideTimeout(long deadline) {
        cancelHideTimeout();
        if (deadline == Long.MAX_VALUE) return;
        long remaining = Math.max(0L, deadline - System.currentTimeMillis());
        hideTimeout = () -> {
            CrashLogger.log(this, "HIDE timeout");
            stopRecording(false);
            prefs().edit().putBoolean(KEY_HIDE_ACTIVE, false).remove(KEY_HIDE_DEADLINE).apply();
            refreshNotification();
            broadcastState();
        };
        main.postDelayed(hideTimeout, remaining);
    }

    private void cancelHideTimeout() {
        if (hideTimeout != null) main.removeCallbacks(hideTimeout);
        hideTimeout = null;
    }

    private void leaveHideKeepingRecording() {
        cancelHideTimeout();
        prefs().edit().putBoolean(KEY_HIDE_ACTIVE, false).remove(KEY_HIDE_DEADLINE).apply();
        refreshNotification();
        CrashLogger.log(this, "HIDE OFF by explicit launcher start; recording preserved");
    }

    private void exitHideForSettings() {
        boolean wasHidden = prefs().getBoolean(KEY_HIDE_ACTIVE, false);
        boolean wasRecording = prefs().getBoolean(KEY_RECORDING, false);
        cancelHideTimeout();
        if (wasRecording) stopRecording(false);
        prefs().edit().putBoolean(KEY_HIDE_ACTIVE, false).remove(KEY_HIDE_DEADLINE).apply();
        refreshNotification();
        CrashLogger.log(this, "HIDE OFF by settings recording_was=" + wasRecording);
        if (wasHidden) main.post(() -> Toast.makeText(this, "録音が停止されました", Toast.LENGTH_SHORT).show());
        broadcastState();
    }

    private void completeStop(String reason) {
        if (completeStopInProgress) return;
        completeStopInProgress = true;
        CrashLogger.log(this, "COMPLETE STOP reason=" + reason);
        cancelHideTimeout();
        stopRecording(false);
        stopAudioInput();
        prefs().edit()
                .putBoolean(KEY_SERVICE_ACTIVE, false)
                .putBoolean(KEY_RECORDING, false)
                .putBoolean(KEY_HIDE_ACTIVE, false)
                .remove(KEY_HIDE_DEADLINE)
                .apply();
        stopForeground(STOP_FOREGROUND_REMOVE);
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.cancel(NOTIFICATION_ID);
        broadcastState();
        stopSelf();
    }

    private void broadcastState() {
        sendBroadcast(new Intent(ACTION_STATE_CHANGED).setPackage(getPackageName()));
        try { TileRefresh.request(this); } catch (Exception ignored) {}
    }

    private abstract static class RecordWriter {
        final File file;
        String displayName;
        volatile boolean closed;
        RecordWriter(File file) { this.file = file; }
        abstract void write(byte[] data, int len) throws Exception;
        abstract void finish() throws Exception;
    }

    private static final class WavWriter extends RecordWriter {
        private final RandomAccessFile raf;
        private final int rate;
        private final int channels;
        private long pcmBytes = 0L;

        WavWriter(File f, int rate, int channels) throws Exception {
            super(f);
            this.rate = rate;
            this.channels = channels;
            raf = new RandomAccessFile(f, "rw");
            for (int i = 0; i < 44; i++) raf.write(0);
        }

        @Override synchronized void write(byte[] data, int len) throws Exception {
            if (closed) return;
            int frame = channels * 2;
            int usable = len - (len % frame);
            if (usable <= 0) return;
            raf.write(data, 0, usable);
            pcmBytes += usable;
        }

        @Override synchronized void finish() throws Exception {
            if (closed) return;
            closed = true;
            raf.seek(0);
            writeAscii(raf, "RIFF");
            writeIntLE(raf, (int)Math.min(0xffffffffL, 36L + pcmBytes));
            writeAscii(raf, "WAVE");
            writeAscii(raf, "fmt ");
            writeIntLE(raf, 16);
            writeShortLE(raf, 1);
            writeShortLE(raf, channels);
            writeIntLE(raf, rate);
            writeIntLE(raf, rate * channels * 2);
            writeShortLE(raf, channels * 2);
            writeShortLE(raf, 16);
            writeAscii(raf, "data");
            writeIntLE(raf, (int)Math.min(0xffffffffL, pcmBytes));
            raf.close();
        }
    }

    private static final class M4aWriter extends RecordWriter {
        private final MediaCodec codec;
        private final MediaMuxer muxer;
        private final MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        private final int channels;
        private final int sampleRate;
        private boolean muxerStarted = false;
        private int trackIndex = -1;
        private long framesSubmitted = 0L;

        M4aWriter(File f, int rate, int channels, int bitrate) throws Exception {
            super(f);
            this.channels = channels;
            this.sampleRate = rate;
            MediaFormat format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, channels);
            format.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            format.setInteger(MediaFormat.KEY_BIT_RATE, bitrate);
            format.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            codec.start();
            muxer = new MediaMuxer(f.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        }

        @Override synchronized void write(byte[] data, int len) throws Exception {
            if (closed) return;
            int frameBytes = channels * 2;
            int offset = 0;
            int usableTotal = len - (len % frameBytes);
            while (offset < usableTotal) {
                int in = codec.dequeueInputBuffer(10_000);
                if (in < 0) {
                    drain(false);
                    continue;
                }
                ByteBuffer b = codec.getInputBuffer(in);
                if (b == null) continue;
                b.clear();
                int piece = Math.min(b.capacity(), usableTotal - offset);
                piece -= piece % frameBytes;
                if (piece <= 0) break;
                b.put(data, offset, piece);
                long pts = framesSubmitted * 1_000_000L / sampleRate;
                codec.queueInputBuffer(in, 0, piece, pts, 0);
                framesSubmitted += piece / frameBytes;
                offset += piece;
                drain(false);
            }
        }

        @Override synchronized void finish() throws Exception {
            if (closed) return;
            closed = true;
            int tries = 0;
            while (tries++ < 100) {
                int in = codec.dequeueInputBuffer(10_000);
                if (in >= 0) {
                    long pts = framesSubmitted * 1_000_000L / sampleRate;
                    codec.queueInputBuffer(in, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                    break;
                }
                drain(false);
            }
            drain(true);
            try { codec.stop(); } finally { codec.release(); }
            try { if (muxerStarted) muxer.stop(); } finally { muxer.release(); }
        }

        private void drain(boolean end) throws Exception {
            int idle = 0;
            while (true) {
                int out = codec.dequeueOutputBuffer(info, end ? 10_000 : 0);
                if (out == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!end || ++idle > 100) break;
                    continue;
                }
                if (out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (muxerStarted) throw new IllegalStateException("format changed twice");
                    trackIndex = muxer.addTrack(codec.getOutputFormat());
                    muxer.start();
                    muxerStarted = true;
                    continue;
                }
                if (out < 0) continue;
                ByteBuffer encoded = codec.getOutputBuffer(out);
                if (encoded != null && (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                        && info.size > 0 && muxerStarted) {
                    encoded.position(info.offset);
                    encoded.limit(info.offset + info.size);
                    muxer.writeSampleData(trackIndex, encoded, info);
                }
                boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                codec.releaseOutputBuffer(out, false);
                if (eos) break;
            }
        }
    }

    private static void writeAscii(RandomAccessFile r, String s) throws Exception {
        r.write(s.getBytes(java.nio.charset.StandardCharsets.US_ASCII));
    }
    private static void writeIntLE(RandomAccessFile r, int v) throws Exception {
        r.write(v & 0xff); r.write((v >>> 8) & 0xff); r.write((v >>> 16) & 0xff); r.write((v >>> 24) & 0xff);
    }
    private static void writeShortLE(RandomAccessFile r, int v) throws Exception {
        r.write(v & 0xff); r.write((v >>> 8) & 0xff);
    }
}
