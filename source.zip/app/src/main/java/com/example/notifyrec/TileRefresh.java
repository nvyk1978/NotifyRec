package com.example.notifyrec;

import android.content.ComponentName;
import android.content.Context;
import android.service.quicksettings.TileService;

final class TileRefresh {
    private TileRefresh() {}
    static void request(Context c) {
        TileService.requestListeningState(c,
                new ComponentName(c, NotificationLauncherTileService.class));
    }
}
