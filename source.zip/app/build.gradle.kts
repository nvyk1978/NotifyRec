plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.notifyrec"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.notifyrec"
        minSdk = 26
        targetSdk = 36
        versionCode = 8
        versionName = "0.1.7"
    }

    signingConfigs {
        create("notifyRecDebug") {
            storeFile = file("notifyrec-debug.jks")
            storePassword = "notifyrec-debug"
            keyAlias = "notifyrec"
            keyPassword = "notifyrec-debug"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("notifyRecDebug")
        }
    }
}
