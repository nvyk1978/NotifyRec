# 通知Rec. v0.1.0

FinderlessCamera系の通知ランチャーUIを使った録音アプリの初期版。

## 初期仕様
- 通知ランチャー起動時からマイクを保持し、AndroidのプライバシーインジケーターをON
- 通知ランチャー: 完全停止 / HIDE / REC(STOP)
- Quick Settingsタイルから通知ランチャー起動
- HIDE: 30分 / 60分 / 無限。HIDE開始時に録音開始。時間満了で録音停止しランチャー復帰
- HIDE中に設定画面を開くと録音停止し「録音が停止されました」
- M4A / WAV、44.1 / 48kHz、64 / 128 / 256kbps、Mono / Stereo、通常マイク / 通話向け
- 議事録: M4A / 48kHz / 128kbps / Mono / 通常マイク
- 素材撮り: M4A / 48kHz / 256kbps / Stereo / 通常マイク
- WAV選択だけは永続保存しない。プロセス再起動時にM4Aへ戻る
- 保存フォルダ選択、診断ログ

## 上書き更新
`app/notifyrec-debug.jks` は通知Rec.専用の固定テスト署名です。
今後のsource.zipでもこのファイルと applicationId `com.example.notifyrec` を維持し、versionCodeを増やしてください。
そうすれば同じ署名のデバッグAPKとして上書きインストールできます。

※ このキーは私用デバッグ配布向けです。Google Play公開用の本番署名には使用しないでください。
